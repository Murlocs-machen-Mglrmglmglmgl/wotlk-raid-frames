# CompactRaidFrame
## Backport CompactRaidFrame from retail for 3.3.5a

## Open -main folder in zip and copy CompactRaidFrame folder to AddOns

## [Download](https://github.com/RomanSpector/CompactRaidFrame/archive/refs/heads/main.zip)

## [Join my Discord](https://discord.gg/wXw6pTvxMQ)

![alt tag](https://media.discordapp.net/attachments/761857830923665418/849274584591368222/CUF-raid.png?width=880&height=627) 
![alt tag](https://media.discordapp.net/attachments/761857830923665418/849274602336419840/CUF-party.png?width=880&height=627) 
![alt tag](https://media.discordapp.net/attachments/761857830923665418/849274598159548436/CUF-options.png?width=880&height=627) 
